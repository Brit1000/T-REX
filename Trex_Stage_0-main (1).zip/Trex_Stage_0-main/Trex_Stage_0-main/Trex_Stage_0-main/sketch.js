
var trex ,trex_running;
function preload(){
  

}

function setup(){
  createCanvas(600,200)
  
  //crie um sprite de trex
 
}

function draw(){
  background("white")
  

}
